"""
foodWebsAnalyzer
========
foodWebsAnalyzer is a Python package for the analysis of throphic networks.
"""

# Import foodWebsAnalyzer objects
from ecosystems.controlSpaces.controlSpaceJacobian import *

__version__ = "0.1"
