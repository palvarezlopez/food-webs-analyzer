"""
foodWebsAnalyzer
========
foodWebsAnalyzer is a Python package for the analysis of throphic networks.
"""

# Import foodWebsAnalyzer objects
from common import * 
from ecosystem import *
from utils import *
from foodweb import *
from foodWebsAnalyzer import *


__version__ = "0.1"