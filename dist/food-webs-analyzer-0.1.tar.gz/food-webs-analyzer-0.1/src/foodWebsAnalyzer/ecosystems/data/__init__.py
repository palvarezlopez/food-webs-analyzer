"""
foodWebsAnalyzer
========
foodWebsAnalyzer is a Python package for the analysis of throphic networks.
"""

# Import foodWebsAnalyzer objects
from ecosystems.data.foodWebData import *
from ecosystems.data.symbolicData import *

__version__ = "0.1"
